
  <div id="book_field">
    <div id="book_image">
      <img id="book_img_l" src="http://pixhost.me/avaxhome/02/d4/0028d402_medium.jpeg">
    </div>
    <div id="book_info">
      <div id="book_name"> 
	<a href="#">
	  <h2> Java programming </h2>
	</a>
      </div>
      <div id="book_des"> good book </div>
    </div>
  </div>
