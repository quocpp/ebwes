<?php
 class db
 {
  public $address = "localhost";
  public $user = "root";
  public $password = "";
  public $db_name = "book";
 }
?>